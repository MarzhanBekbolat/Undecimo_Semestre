#ifndef HELLOWORLD_H_
#define HELLOWORLD_H_

#include <systemc.h>

int main()
{ 
cout<< "HELLOWORLD" <<endl;
cout<< "nicolas" <<endl;
return 0;
}

#endif /*HELLOWORLD_H_*/
