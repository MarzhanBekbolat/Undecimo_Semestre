char simple_bus_status_str[4][20] = {"SIMPLE_BUS_OK"
                                      , "SIMPLE_BUS_REQUEST"
                                      , "SIMPLE_BUS_WAIT"
                                      , "SIMPLE_BUS_ERROR"};
